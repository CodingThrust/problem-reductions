import os,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from check_website import serve_website
from test_website import WebsiteTests
from playwright.sync_api import expect
class Case(WebsiteTests):
    def test_native_cold_query_finishes(self):
        self.page.goto(self.base+'graph.html')
        self.choose_endpoint('source','MVC')
        self.page.locator('#source-options [aria-label="weight"]').get_by_role('button',name='One',exact=True).click()
        self.choose_endpoint('target','LongestCommonSubsequence')
        try:
            expect(self.page.locator('.path').first.locator('.size')).to_have_text('?',timeout=3000)
            expect(self.page.locator('#results .summary strong')).to_contain_text('best route',timeout=500)
        except Exception:
            print('ENDPOINTS',self.page.locator('#source').input_value(),self.page.locator('#target').input_value(),flush=True)
            print('RESULTS',self.page.locator('#results').inner_text()[:500],flush=True)
            print('PAGE MARKS',self.page.evaluate('performance.getEntriesByType("mark").map(m=>({name:m.name,start:m.startTime}))'),flush=True)
            for worker in self.page.workers:
                try: print('WORKER',worker.url,worker.evaluate('performance.getEntriesByType("mark").map(m=>({name:m.name,start:m.startTime}))'),flush=True)
                except Exception as error: print('WORKER UNAVAILABLE',worker.url,str(error),flush=True)
            raise
with serve_website(Path(sys.argv[1])) as base:
    os.environ['WEBSITE_BASE_URL']=base
    os.environ['WEBSITE_BROWSER']='firefox'
    result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(Case('test_native_cold_query_finishes') for _ in range(10)))
    raise SystemExit(not result.wasSuccessful())
